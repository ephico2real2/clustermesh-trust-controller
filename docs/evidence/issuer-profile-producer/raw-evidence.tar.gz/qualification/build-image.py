from pathlib import Path
import subprocess,json,io,tarfile,hashlib
out=Path('/private/tmp/cmtc-issuer-profile-20261024')
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert sha.startswith('7e60619'),sha
src=out/'committed-source';src.mkdir()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',sha]))) as tf:tf.extractall(src,filter='data')
for rel,digest in json.loads((out/'tested-go-source-hashes.json').read_text()).items():
 assert hashlib.sha256((src/rel).read_bytes()).hexdigest()==digest,rel
image='localhost/cmtc:issuer-'+sha[:10]
builder='f0093acd3f0ab3a1966ebe348eaa3c78ac706f94839f52209ae7120508cf2529'
runtime='gcr.io/distroless/static-debian13@sha256:18f4cc26c9ffa7f20a359298be7deadac5c607c8e03a02b8119f1a5fc2f82c99'
base=['podman','--connection','cmtc-ubuntu-build']
cmd=base+['build','--platform','linux/arm64','--build-arg','BUILDPLATFORM=linux/arm64','--build-arg','TARGETOS=linux','--build-arg','TARGETARCH=arm64','--build-arg','BUILD_IMAGE='+builder,'--build-arg','RUNTIME_IMAGE='+runtime,'--jobs','1','--memory','3g']
for name,value in [('GOMAXPROCS','2'),('GOMEMLIMIT','1536MiB'),('GOFLAGS','-p=2'),('GOCACHE','/cache'),('GOMODCACHE','/gomod')]:cmd+=['--env',name+'='+value,'--unsetenv',name]
cmd+=['-v','/private/tmp/cmtc-observer-go-cache:/cache','-v','/private/tmp/cmtc-observer-mod-cache:/gomod','--label','org.opencontainers.image.revision='+sha,'--label','org.opencontainers.image.source=https://github.com/ephico2real2/clustermesh-trust-controller','--label','io.cmtc.build.toolchain=go1.27.3','-t',image,str(src)]
(out/'build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'image-build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
actual=json.loads(subprocess.check_output(base+['image','inspect',image]))[0]
assert actual['Architecture']=='arm64' and actual['Os']=='linux'
assert actual['Labels']['org.opencontainers.image.revision']==sha
helptext=subprocess.check_output(base+['run','--rm','--network','none','--memory','256m',image,'--help'],stderr=subprocess.STDOUT,text=True)
assert 'issuer-profile-producer' in helptext
(out/'help.txt').write_text(helptext)
package=out/'package';package.mkdir()
cid=subprocess.check_output(base+['create','--network','none',image,'--help'],text=True).strip()
try:
 for binary in ['cmtc','lab-ca-init','lab-identity-init']:subprocess.run(base+['cp',cid+':/'+binary,str(package/binary)],check=True)
finally:subprocess.run(base+['rm',cid],check=True,stdout=subprocess.DEVNULL)
archive=out/'cmtc-arm64.tar'
subprocess.run(base+['save','--format','docker-archive','-o',str(archive),image],check=True)
archive_sha=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
ledger={'source':sha,'image':image,'imageConfigurationID':'sha256:'+actual['Id'].removeprefix('sha256:'),'architecture':actual['Architecture'],'builderConfigID':'sha256:'+builder,'toolchain':'go1.27.3','runtime':runtime,'archiveSHA256':archive_sha,'binarySHA256':{p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in package.iterdir()},'labels':actual['Labels']}
(out/'image.json').write_text(json.dumps(ledger,indent=2)+'\n')
(out/'cmtc-arm64.tar.sha256').write_text(archive_sha+'  cmtc-arm64.tar\n')
print(json.dumps(ledger),flush=True)
