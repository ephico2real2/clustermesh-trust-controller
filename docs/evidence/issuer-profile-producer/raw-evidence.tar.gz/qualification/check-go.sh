#!/usr/bin/env bash
set -euo pipefail
out=/private/tmp/cmtc-issuer-profile-20261024
trap 'status=$?; printf "%s\n" "$status" > "$out/go-check.exit"' EXIT
podman --connection cmtc-ubuntu-build run --rm --platform linux/arm64 \
 --cpus 2 --memory 3g --security-opt label=disable \
 -e GOMAXPROCS=2 -e GOMEMLIMIT=1536MiB -e GOFLAGS=-p=2 -e GOCACHE=/cache -e GOMODCACHE=/gomod \
 -v "$out/source:/src" -v /private/tmp/cmtc-observer-go-cache:/cache \
 -v /private/tmp/cmtc-observer-mod-cache:/gomod -w /src \
 f0093acd3f0ab3a1966ebe348eaa3c78ac706f94839f52209ae7120508cf2529 \
 sh -ec 'test -z "$(gofmt -l cmd/cmtc internal/trustprofile internal/controller/issuer_profile.go internal/controller/issuer_profile_test.go)"; go test -race -json -count=1 ./...; go vet ./...' > "$out/full-second.jsonl" 2>&1
