from pathlib import Path
import subprocess,json,os
out=Path('/private/tmp/cmtc-issuer-profile-20261024'); image=json.loads((out/'image.json').read_text())
env={**os.environ,'DOCKER_HOST':'unix:///Users/olasumbo/.colima/cmtc-cilium/docker.sock','KIND_EXPERIMENTAL_PROVIDER':'docker'}
for cluster in ['cmtc-a','cmtc-b']:
 with (out/f'load-{cluster}.log').open('w') as log:subprocess.run(['kind','load','image-archive',str(out/'cmtc-arm64.tar'),'--name',cluster],env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
verified={}
for cluster in ['cmtc-a','cmtc-b']:
 for node in [cluster+'-control-plane',cluster+'-worker']:
  raw=subprocess.check_output(['colima','ssh','--profile','cmtc-cilium','--','docker','exec',node,'crictl','inspecti',image['image']],text=True)
  (out/f'import-{node}.json').write_text(raw);actual=json.loads(raw);spec=actual['info']['imageSpec'];status=actual['status']
  assert status['id']==image['imageConfigurationID'] and spec['architecture']=='arm64'
  assert spec['config']['Labels']['org.opencontainers.image.revision']==image['source']
  verified[node]={'image':image['image'],'imageConfigurationID':status['id'],'architecture':spec['architecture'],'source':image['source'],'repoDigests':status['repoDigests']}
(out/'loaded-images.json').write_text(json.dumps(verified,indent=2)+'\n')
print('Exact source/config/ARM64 verified on all four nodes.',flush=True)
