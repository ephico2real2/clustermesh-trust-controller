from pathlib import Path
import json,time,urllib.request,urllib.parse,datetime
report=Path('/private/tmp/cmtc-issuer-profile-live-third/cmtc-b/report.json')
out=Path('/private/tmp/cmtc-issuer-profile-20261024/central-b-ms.json')
base='http://127.0.0.1:13000/api/datasources/proxy/uid/cmtc-prom/api/v1/query?'
deadline=time.monotonic()+300
last='no scrape yet'
while time.monotonic()<deadline:
 try:
  d=json.loads(report.read_text())
  events=[e for e in d['events'] if e['stage']=='scrape']
  if not events:time.sleep(3);continue
  local=events[-1];labels=local['target']['labels'];selector='{job="cmtc",component="cmtc-controller",cluster="cmtc-b",instance="'+labels['instance']+'"}'
  evidence={};fresh=True
  floor=datetime.datetime.fromisoformat(local['target']['lastScrape'].replace('Z','+00:00')).timestamp()
  for name in local['families']:
   def query(q):
    with urllib.request.urlopen(base+urllib.parse.urlencode({'query':q}),timeout=12) as r:return json.load(r)
   values=query(name+selector);stamps=query('timestamp('+name+selector+')');rows=stamps['data']['result']
   if not rows or not values['data']['result'] or any(not floor-0.010<=float(r['value'][1])<=time.time() or time.time()-float(r['value'][1])>20 for r in rows):fresh=False
   evidence[name]={'values':values,'sampleTimestamps':stamps}
  if fresh:
   out.write_text(json.dumps({'cluster':'cmtc-b','scope':'fresh central remote-write producer telemetry only; no trust consumption or mTLS proof','localTarget':local['target'],'timestampToleranceSeconds':0.010,'central':evidence},indent=2)+'\n');print('Fresh B-to-A remote-write verified for all four producer families.',flush=True);break
 except (OSError,ValueError,KeyError) as e:last=str(e)
 time.sleep(3)
else:raise SystemExit('No fresh central B metrics: '+last)
