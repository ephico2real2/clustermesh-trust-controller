from pathlib import Path
import subprocess,json,hashlib,datetime
out=Path('/private/tmp/cmtc-issuer-profile-20261024/baseline-rollout');out.mkdir(exist_ok=False)
image=json.loads(Path('/private/tmp/cmtc-issuer-profile-20261024/image.json').read_text());ledger=[];seq=0
owner='security.cmtc.io/issuer-profile-lab-run'
def run(args,data=None):
 global seq
 seq+=1
 p=subprocess.run(args,input=None if data is None else json.dumps(data),text=True,capture_output=True,timeout=190)
 (out/f'{seq:03d}.json').write_text(json.dumps({'argv':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2))
 if p.returncode:raise RuntimeError(f'command {seq} failed: '+p.stderr[-1000:])
 return p.stdout
for cluster in ['cmtc-a','cmtc-b']:
 k=['kubectl','--kubeconfig','/private/tmp/cmtc-a-b-20261024.kubeconfig','--context','kind-'+cluster,'--request-timeout=170s','-n','cmtc-system']
 for kind,name in [('deployment','cmtc-controller'),('daemonset','cmtc-node-agent')]:
  obj=json.loads(run(k+['get',kind,name,'-o','json']));template=obj['spec']['template']
  if owner in obj['metadata'].get('annotations',{}) or owner in template['metadata'].get('annotations',{}):raise RuntimeError('active lab owner')
  cs=template['spec']['containers']
  if len(cs)!=1 or cs[0]['image']!='localhost/cmtc:observe-b193510f20' or any(x.startswith('--issuer-profile') for x in cs[0].get('args',[])):raise RuntimeError('unexpected current configuration')
  patch=[{'op':'test','path':'/metadata/uid','value':obj['metadata']['uid']},{'op':'test','path':'/metadata/resourceVersion','value':obj['metadata']['resourceVersion']},{'op':'test','path':'/spec/template','value':template},{'op':'replace','path':'/spec/template/spec/containers/0/image','value':image['image']}]
  run(k+['patch',kind,name,'--type=json','-p',json.dumps(patch)])
  run(k+['rollout','status',kind+'/'+name,'--timeout=150s'])
  after=json.loads(run(k+['get',kind,name,'-o','json']));expected=json.loads(json.dumps(template));expected['spec']['containers'][0]['image']=image['image']
  if after['metadata']['uid']!=obj['metadata']['uid'] or after['spec']['template']!=expected:raise RuntimeError('unexpected post-rollout template change')
 pods=json.loads(run(k+['get','pods','-o','json']))['items'];found=[]
 for pod in pods:
  if pod['metadata'].get('deletionTimestamp'):continue
  if pod['metadata'].get('labels',{}).get('app.kubernetes.io/name') not in {'cmtc-controller','cmtc-node-agent'}:continue
  if len(pod['spec']['containers'])!=1 or pod['spec']['containers'][0]['image']!=image['image']:raise RuntimeError('unexpected Pod image')
  statuses=pod['status'].get('containerStatuses',[])
  if len(statuses)!=1 or not statuses[0].get('ready'):raise RuntimeError('container not ready')
  node=pod['spec']['nodeName'];docker=['colima','ssh','--profile','cmtc-cilium','--','docker','exec',node]
  actual=json.loads(run(docker+['crictl','inspecti',image['image']]));spec=actual['info']['imageSpec'];status=actual['status']
  if status['id']!=image['imageConfigurationID'] or spec['architecture']!='arm64' or spec['config']['Labels']['org.opencontainers.image.revision']!=image['source']:raise RuntimeError('CRI image identity mismatch')
  digest=statuses[0]['imageID'].split('://',1)[-1].rsplit('@',1)[-1]
  if digest not in {s.rsplit('@',1)[-1] for s in status['repoDigests']}:raise RuntimeError('running manifest not bound to image config')
  cid=statuses[0]['containerID'].split('://',1)[-1];pid=json.loads(run(docker+['crictl','inspect',cid]))['info']['pid']
  if type(pid)is not int or pid<2:raise RuntimeError('unexpected PID')
  binary=run(docker+['sha256sum',f'/proc/{pid}/root/cmtc']).split()[0]
  if binary!=image['binarySHA256']['cmtc']:raise RuntimeError('running binary differs')
  found.append({'pod':pod['metadata']['name'],'podUID':pod['metadata']['uid'],'node':node,'imageID':statuses[0]['imageID'],'configID':status['id'],'source':image['source'],'binarySHA256':binary})
 if len(found)!=3 or len({x['node'] for x in found})!=2:raise RuntimeError('expected one controller and two node agents')
 ledger.extend(found)
(out/'summary.json').write_text(json.dumps({'image':image,'containers':ledger,'producerEnabled':False,'mode':'Observe','workloadMTLS':False,'scope':'qualified CMTC binary baseline; issuer producer remains explicit opt-in after trial cleanup'},indent=2)+'\n')
print('All six CMTC containers run the exact qualified image and binary; baseline remains Observe.',flush=True)
