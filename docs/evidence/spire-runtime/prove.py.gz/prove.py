from pathlib import Path
import json,subprocess,sys,hashlib
root=Path('/Users/olasumbo/gitRepos/clustermest-trust-controller');out=Path('/private/tmp/cmtc-spire-deploy-20261024');pki=Path('/private/tmp/cmtc-spire-ca-opaque-20261024');pins=json.loads((pki/'cluster-pins.json').read_text());created=json.loads((out/'created.json').read_text());py='/Users/olasumbo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
for c in ['cmtc-a','cmtc-b']:
 base=['kubectl','--kubeconfig','/private/tmp/cmtc-a-b-20261024.kubeconfig','--context','kind-'+c]
 pod=json.loads(subprocess.check_output(base+['-n','cilium-spire','get','pod','spire-server-0','-o','json']))
 sts=[x for x in created[c] if x['kind']=='StatefulSet'];assert len(sts)==1;assert pod['metadata']['ownerReferences'][0]['uid']==sts[0]['metadata']['uid']
 node=pod['spec']['nodeName'];assert node in pins[c]['nodes']
 actual=json.loads(subprocess.check_output(base+['get','node',node,'-o','json']));assert actual['metadata']['uid']==pins[c]['nodes'][node]
 pub=json.loads((pki/(c+'-pki.stdout')).read_text())['publication']
 cmd=[py,str(root/'scripts/lab/spire/public_proof.py'),'--pki-module',str(root/'scripts/lab/pki/pki.py'),'--kubeconfig','/private/tmp/cmtc-a-b-20261024.kubeconfig','--cluster',c,'--cluster-uid',pins[c]['clusterUID'],'--pod-uid',pod['metadata']['uid'],'--approval-uid',pub['approvalUID'],'--root-sha256',pub['rootSHA256']]
 (out/(c+'-proof-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (out/(c+'-proof.json')).open('w') as f,(out/(c+'-proof.stderr')).open('w') as e: r=subprocess.run(cmd,stdout=f,stderr=e,timeout=50)
 (out/(c+'-proof.exit')).write_text(str(r.returncode))
 if r.returncode:sys.exit(r.returncode)
 print(c,'PASS actual nonce-mint direct issuer and approved lineage',flush=True)
