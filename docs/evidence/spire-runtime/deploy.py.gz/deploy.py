import sys,json,subprocess,hashlib,importlib.util
from pathlib import Path
root=Path('/Users/olasumbo/gitRepos/clustermest-trust-controller');out=Path('/private/tmp/cmtc-spire-deploy-20261024')
sys.path.insert(0,str(root/'scripts/lab/spire'));import render_spire as r
kubeconfig='/private/tmp/cmtc-a-b-20261024.kubeconfig'
pins=json.loads(Path('/private/tmp/cmtc-spire-ca-opaque-20261024/cluster-pins.json').read_text())
(out/'renderer.sha256').write_text(hashlib.sha256((root/'scripts/lab/spire/render_spire.py').read_bytes()).hexdigest())
def k(c,*args,data=None):
 p=subprocess.run(['kubectl','--kubeconfig',kubeconfig,'--context','kind-'+c,*args],input=None if data is None else json.dumps(data),text=True,capture_output=True,timeout=40)
 if p.returncode:raise RuntimeError(p.stderr)
 values=[]; remaining=p.stdout.strip(); decoder=json.JSONDecoder()
 while remaining:
  value,end=decoder.raw_decode(remaining);values.append(value);remaining=remaining[end:].lstrip()
 if len(values)>1:return {'apiVersion':'v1','kind':'List','items':values}
 return values[0] if values else None

def snapshot(c):
 n=k(c,'get','nodes','-o','json')['items'];uid=k(c,'get','namespace','kube-system','-o','json')['metadata']['uid']
 assert uid==pins[c]['clusterUID']; assert {v['metadata']['name']:v['metadata']['uid'] for v in n}==pins[c]['nodes']
 ds=k(c,'-n','kube-system','get','ds','cilium','-o','json');cm=k(c,'-n','kube-system','get','cm','cilium-config','-o','json');cert=k(c,'-n','cert-manager','get','deploy','cert-manager','-o','json')
 return {'clusterUID':uid,'nodes':pins[c]['nodes'],'ciliumUID':ds['metadata']['uid'],'ciliumSpec':ds['spec'],'ciliumConfigUID':cm['metadata']['uid'],'ciliumConfig':cm['data'],'certManagerUID':cert['metadata']['uid'],'certManagerSpec':cert['spec']}
created=json.loads((out/'created.json').read_text()) if (out/'created.json').exists() else {};before={}
for c in r.CLUSTERS:
 before[c]=snapshot(c);(out/(c+'-before.json')).write_text(json.dumps(before[c],indent=2)+'\n')
 docs=r.render(c);ns=docs[0];assert ns['kind']=='Namespace'
 if c in created:
  assert len(created[c])==1 and created[c][0]['kind']=='Namespace'
  current=k(c,'get','namespace',r.NAMESPACE,'-o','json')
  assert current['metadata']['uid']==created[c][0]['metadata']['uid']
  assert current['metadata']['labels']==created[c][0]['metadata']['labels']
 else:created[c]=[k(c,'create','-f','-','-o','json',data=ns)]
 (out/'created.json').write_text(json.dumps(created,indent=2)+'\n')
 rest={'apiVersion':'v1','kind':'List','items':docs[1:]}
 (out/(c+'-manifest.json')).write_text(json.dumps(rest,indent=2)+'\n')
 dry=k(c,'create','--dry-run=server','--validate=strict','-f','-','-o','json',data=rest)
 (out/(c+'-server-dry-run.json')).write_text(json.dumps(dry,indent=2)+'\n')
for c in r.CLUSTERS:
 rest=json.loads((out/(c+'-manifest.json')).read_text());actual=k(c,'create','--validate=strict','-f','-','-o','json',data=rest)
 created[c]+=actual['items'];(out/'created.json').write_text(json.dumps(created,indent=2)+'\n')
 after=snapshot(c);assert after==before[c],c+' existing lab snapshot changed';(out/(c+'-after.json')).write_text(json.dumps(after,indent=2)+'\n')
print('Standalone SPIRE dependency objects created in both clusters; runtime readiness unverified.')
