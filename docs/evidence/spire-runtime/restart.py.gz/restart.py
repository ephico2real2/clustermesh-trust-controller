from pathlib import Path
import subprocess,json,time
out=Path('/private/tmp/cmtc-spire-deploy-20261024/restart');out.mkdir(exist_ok=True)
created=json.loads((out.parent/'created.json').read_text())
def k(c,*args,data=None):
 p=subprocess.run(['kubectl','--kubeconfig','/private/tmp/cmtc-a-b-20261024.kubeconfig','--context','kind-'+c,*args],input=json.dumps(data) if data is not None else None,text=True,capture_output=True,timeout=30)
 if p.returncode:raise RuntimeError(p.stderr)
 return json.loads(p.stdout) if p.stdout.strip() else None
for c in ['cmtc-a','cmtc-b']:
 pod=k(c,'-n','cilium-spire','get','pod','spire-server-0','-o','json');m=pod['metadata'];assert len(pod['status']['containerStatuses'])==2 and all(s['ready'] for s in pod['status']['containerStatuses'])
 sts=[x for x in created[c] if x['kind']=='StatefulSet'][0];assert m['ownerReferences'][0]['uid']==sts['metadata']['uid']
 pvc=k(c,'-n','cilium-spire','get','pvc','spire-data-spire-server-0','-o','json');assert pvc['status']['phase']=='Bound'
 before={'pod':pod,'pvc':pvc};(out/(c+'-before.json')).write_text(json.dumps(before,indent=2)+'\n')
 options={'apiVersion':'v1','kind':'DeleteOptions','preconditions':{'uid':m['uid'],'resourceVersion':m['resourceVersion']},'gracePeriodSeconds':20}
 result=k(c,'delete','--raw','/api/v1/namespaces/cilium-spire/pods/spire-server-0','-f','-',data=options)
 (out/(c+'-delete-ack.json')).write_text(json.dumps(result,indent=2)+'\n')
 deadline=time.monotonic()+150
 while time.monotonic()<deadline:
  try:new=k(c,'-n','cilium-spire','get','pod','spire-server-0','-o','json')
  except RuntimeError:time.sleep(.5);continue
  if new['metadata']['uid']!=m['uid'] and not new['metadata'].get('deletionTimestamp') and len(new.get('status',{}).get('containerStatuses',[]))==2 and all(s['ready'] for s in new['status']['containerStatuses']):break
  time.sleep(.5)
 else:raise RuntimeError(c+' restarted SPIRE Pod did not become ready')
 afterpvc=k(c,'-n','cilium-spire','get','pvc','spire-data-spire-server-0','-o','json')
 assert afterpvc['metadata']['uid']==pvc['metadata']['uid'] and afterpvc['spec']['volumeName']==pvc['spec']['volumeName']
 assert new['metadata']['ownerReferences'][0]['uid']==sts['metadata']['uid']
 (out/(c+'-after.json')).write_text(json.dumps({'pod':new,'pvc':afterpvc},indent=2)+'\n')
 print(c,'Ready after UID/RV conditional Pod restart; PVC and StatefulSet identities retained',flush=True)
(out/'created.json').write_text(json.dumps(created,indent=2)+'\n')
s=(out.parent/'prove.py').read_text().replace("out=Path('/private/tmp/cmtc-spire-deploy-20261024')","out=Path('/private/tmp/cmtc-spire-deploy-20261024/restart')")
(out/'prove.py').write_text(s)
