from pathlib import Path
import json,os,subprocess
out=Path('/private/tmp/cmtc-pinned-tls-20261024')
sha='ddb255de68cd458945f831cb1ab66f2f3f135d0c'
image='localhost/cmtc-ztunnel:pins-'+sha[:10]
config='sha256:09207d73016a90518449b78879b1813e8dc134bc82eed899a66ae7ed6ff76880'
env={**os.environ,'KUBECONFIG':'/private/tmp/cmtc-a-b-20261024.kubeconfig','DOCKER_HOST':'unix:///Users/olasumbo/.colima/cmtc-cilium/docker.sock','KIND_EXPERIMENTAL_PROVIDER':'docker'}
def run(cmd,**kwargs):return subprocess.run(cmd,env=env,check=True,text=True,**kwargs)
def get(cmd):return run(cmd,stdout=subprocess.PIPE).stdout
verified={}
for cluster in ('cmtc-a','cmtc-b'):
 with (out/f'load-{cluster}.log').open('w') as log:
  run(['kind','load','image-archive',str(out/'ztunnel-arm64.tar'),'--name',cluster],stdout=log,stderr=subprocess.STDOUT)
 for node in (cluster+'-control-plane',cluster+'-worker'):
  raw=get(['colima','ssh','--profile','cmtc-cilium','--','docker','exec',node,'crictl','inspecti',image])
  actual=json.loads(raw)
  (out/f'import-{node}.json').write_text(raw)
  assert actual['status']['id']==config,(node,actual['status']['id'])
  assert actual['info']['imageSpec']['architecture']=='arm64'
  verified[node]={'image':image,'configurationID':config,'architecture':'arm64','repoDigests':actual['status']['repoDigests']}
(out/'loaded-images.json').write_text(json.dumps(verified,indent=2)+'\n')
cleanup=[]
for cluster in ('cmtc-a','cmtc-b'):
 base=['kubectl','--context','kind-'+cluster,'-n','cmtc-system']
 for node in (cluster+'-control-plane',cluster+'-worker'):
  name='ztunnel-pins-'+sha[:10]+'-'+node
  job={'apiVersion':'batch/v1','kind':'Job','metadata':{'name':name,'namespace':'cmtc-system','labels':{'app.kubernetes.io/managed-by':'cmtc-local-validation','security.cmtc.io/trial':'pinned-tls-ddb255de68'}},'spec':{'activeDeadlineSeconds':120,'backoffLimit':0,'template':{'metadata':{'labels':{'app.kubernetes.io/name':'ztunnel-image-validation'}},'spec':{'nodeName':node,'restartPolicy':'Never','automountServiceAccountToken':False,'tolerations':[{'operator':'Exists'}],'securityContext':{'runAsNonRoot':True,'runAsUser':65532,'seccompProfile':{'type':'RuntimeDefault'}},'containers':[{'name':'version','image':image,'imagePullPolicy':'Never','args':['version'],'resources':{'requests':{'cpu':'10m','memory':'32Mi'},'limits':{'cpu':'200m','memory':'128Mi'}},'securityContext':{'allowPrivilegeEscalation':False,'readOnlyRootFilesystem':True,'capabilities':{'drop':['ALL']}}}]}}}}
  created=json.loads(run(base+['create','-f','-','-o','json'],input=json.dumps(job),stdout=subprocess.PIPE).stdout)
  uid=created['metadata']['uid']
  try:
   run(base+['wait','--for=condition=Complete','job/'+name,'--timeout=120s'],stdout=subprocess.PIPE)
   log=get(base+['logs','job/'+name])
   assert sha in log and 'BuildStatus:"Clean"' in log,log
   (out/(name+'.log')).write_text(log)
   pods=json.loads(get(base+['get','pods','-l','job-name='+name,'-o','json']))['items']
   assert len(pods)==1 and pods[0]['status']['phase']=='Succeeded'
   pod=pods[0]; status=pod['status']['containerStatuses'][0]
   observed=status['imageID'].split('://')[-1]
   accepted={config}|{ref.split('@')[-1] for ref in verified[node]['repoDigests']}
   assert observed in accepted,(node,observed,accepted)
   assert pod['spec']['nodeName']==node and status['state']['terminated']['exitCode']==0
   (out/(name+'-pod.json')).write_text(json.dumps(pod,indent=2)+'\n')
   verified[node]['versionJob']={'uid':uid,'podUID':pod['metadata']['uid'],'podImageID':status['imageID'],'version':log.strip(),'exitCode':0}
   print('PASS',node,config,flush=True)
  finally:
   options={'apiVersion':'v1','kind':'DeleteOptions','propagationPolicy':'Foreground','preconditions':{'uid':uid}}
   uri=f'/apis/batch/v1/namespaces/cmtc-system/jobs/{name}'
   run(base+['delete','--raw',uri,'-f','-'],input=json.dumps(options),stdout=subprocess.PIPE)
   run(base+['wait','--for=delete','job/'+name,'--timeout=90s'],stdout=subprocess.PIPE)
   cleanup.append({'name':name,'uid':uid,'deleted':True})
   (out/'version-job-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
   (out/'loaded-images.json').write_text(json.dumps(verified,indent=2)+'\n')
assert len(cleanup)==4
print('All four exact-image version Jobs passed and were UID-safely removed. No proxy activated.',flush=True)
